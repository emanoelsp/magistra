"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CloudUpload } from "lucide-react";

import { templatesService } from "../../lib/services/firestore/templates.service";

interface TemplatesUploaderProps {
  userId: string;
}

export function TemplatesUploader({ userId }: TemplatesUploaderProps) {
  const router = useRouter();
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [escolaNome, setEscolaNome] = useState("");
  const [tipoPlano, setTipoPlano] = useState("");

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;

    if (!escolaNome.trim() || !tipoPlano.trim()) {
      setError("Informe o nome da escola e o tipo de plano antes de enviar o arquivo.");
      return;
    }

    setError(null);
    setIsUploading(true);

    try {
      const file = files[0];

      const templateId = await templatesService.createTemplate({
        user_id: userId,
        nome: file.name.replace(/\.(pdf|docx?)$/i, ""),
        escola_nome: escolaNome,
        tipo_plano: tipoPlano,
        schema_campos: [],
      });

      // Envia o PDF para a rota de introspecção, que extrai os campos e atualiza o template
      const formData = new FormData();
      formData.append("templateId", templateId);
      formData.append("file", file);

      await fetch("/api/templates/introspect", {
        method: "POST",
        body: formData,
      });

      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Não foi possível criar o template.";
      setError(message);
    } finally {
      setIsUploading(false);
    }
  }

  function onDrop(event: React.DragEvent<HTMLDivElement>) {
    event.preventDefault();
    void handleFiles(event.dataTransfer.files);
  }

  function onDragOver(event: React.DragEvent<HTMLDivElement>) {
    event.preventDefault();
  }

  return (
    <div
      onDrop={onDrop}
      onDragOver={onDragOver}
      className="flex h-full cursor-pointer flex-col items-start gap-4 rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-8"
    >
      <div className="flex w-full flex-col gap-4">
        <div className="grid gap-4 md:grid-cols-2">
          <label className="block text-sm">
            <span className="font-medium text-slate-700">Nome da escola</span>
            <input
              type="text"
              value={escolaNome}
              onChange={(event) => setEscolaNome(event.target.value)}
              className="mt-2 w-full rounded-2xl border border-slate-300 px-3 py-2 text-sm text-slate-950 outline-none transition focus:border-slate-950"
              placeholder="Ex.: Escola Municipal João XXIII"
            />
          </label>

          <label className="block text-sm">
            <span className="font-medium text-slate-700">Tipo de plano</span>
            <select
              value={tipoPlano}
              onChange={(event) => setTipoPlano(event.target.value)}
              className="mt-2 w-full rounded-2xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-950 outline-none transition focus:border-slate-950"
            >
              <option value="">Selecione um tipo</option>
              <option value="plano_anual">Plano anual</option>
              <option value="plano_semestral">Plano semestral</option>
              <option value="plano_quinzenal">Plano quinzenal</option>
              <option value="plano_de_aula">Plano de aula</option>
              <option value="sequencia_didatica">Sequência didática</option>
              <option value="situacao_de_aprendizagem">Situação de aprendizagem</option>
              <option value="projeto_de_extensao">Projeto de extensão</option>
              <option value="caso_de_uso">Caso de uso</option>
            </select>
          </label>
        </div>

        <label className="flex w-full cursor-pointer items-start gap-4">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-900 text-white">
          <CloudUpload className="h-5 w-5" />
        </span>
        <div className="flex-1">
          <h2 className="text-lg font-semibold text-slate-950">
            Upload de template (PDF ou DOCX)
          </h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">
            Arraste e solte um arquivo ou clique para selecionar. O arquivo será salvo como um template
            base e você poderá usá-lo imediatamente no gerador de planos. A extração automática de campos
            será adicionada em uma próxima etapa.
          </p>
          <p className="mt-3 text-xs text-slate-500">
            No momento, apenas o nome do arquivo é usado como nome do template. Os campos podem ser
            definidos manualmente depois.
          </p>
        </div>
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          className="hidden"
          onChange={(event) => {
            void handleFiles(event.target.files);
          }}
          disabled={isUploading}
        />
      </label>
      </div>

      {isUploading ? (
        <p className="text-xs text-slate-600">Carregando template...</p>
      ) : (
        <p className="text-xs text-slate-500">
          Solte um arquivo aqui ou clique na área acima.
        </p>
      )}

      {error ? (
        <p className="text-xs text-rose-600">
          {error}
        </p>
      ) : null}
    </div>
  );
}

