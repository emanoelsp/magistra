"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import { templatesService } from "../../lib/services/firestore/templates.service";
import type { TemplateOption } from "../../lib/types/firestore";

interface TemplatesListProps {
  templates: TemplateOption[];
}

export function TemplatesList({ templates }: TemplatesListProps) {
  const router = useRouter();
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleDelete(templateId: string) {
    setError(null);
    setDeletingId(templateId);

    try {
      await templatesService.deleteTemplate(templateId);
      router.refresh();
    } catch (err) {
      const message = err instanceof Error ? err.message : "Não foi possível excluir o template.";
      setError(message);
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <>
      {error ? (
        <p className="mb-3 text-xs text-rose-600">
          {error}
        </p>
      ) : null}

      <ul className="mt-4 space-y-3 text-sm">
        {templates.map((template) => (
          <li
            key={template.id}
            className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
          >
            <div>
              <p className="font-medium text-slate-900">{template.nome}</p>
              <p className="mt-1 text-xs text-slate-600">
                {template.escolaNome ?? "Escola não informada"} ·{" "}
                {template.tipoPlano
                  ? template.tipoPlano
                      .replace(/_/g, " ")
                      .replace(/\b\w/g, (char) => char.toUpperCase())
                  : "Tipo não informado"}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                {template.campoCount} campos estruturados · criado em{" "}
                <span className="font-medium">{new Date(template.criadoEm).toLocaleDateString("pt-BR")}</span>
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                Pronto para gerar
              </span>
              <button
                type="button"
                onClick={() => {
                  void handleDelete(template.id);
                }}
                disabled={deletingId === template.id}
                className="inline-flex items-center justify-center rounded-2xl border border-rose-200 px-3 py-1.5 text-xs font-medium text-rose-700 transition hover:border-rose-500 hover:text-rose-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {deletingId === template.id ? "Excluindo..." : "Excluir"}
              </button>
            </div>
          </li>
        ))}
      </ul>
    </>
  );
}

