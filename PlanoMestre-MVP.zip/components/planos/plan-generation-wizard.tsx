"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  ArrowLeft,
  ArrowRight,
  BookCheck,
  Check,
  LoaderCircle,
  ShieldCheck,
  Sparkles,
  WandSparkles,
} from "lucide-react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { planosService } from "../../lib/services/firestore/planos.service";
import type {
  GerarPlanoWizardValues,
  IaSugestao,
  TemplateFieldSchema,
  TemplateOption,
} from "../../lib/types/firestore";

const etapasEnsino = ["Educação Infantil", "Ensino Fundamental", "Ensino Médio"] as const;

const wizardSchema = z.object({
  templateId: z.string().min(1, "Selecione um template para continuar."),
  nomeTurma: z.string().min(2, "Informe a identificação da turma."),
  etapaEnsino: z.enum(etapasEnsino, {
    errorMap: () => ({ message: "Selecione a etapa de ensino." }),
  }),
  anoSerie: z.string().min(1, "Informe o ano ou série."),
  componenteCurricular: z.string().min(2, "Informe o componente curricular."),
  quantidadeAulas: z.coerce.number().int().min(1).max(20),
  contextoTurma: z.string().min(20).max(1200),
  objetivoGeral: z.string().min(20).max(600),
  habilidadesBncc: z.string().min(5),
  referenciaSaeb: z.string().min(5).max(300),
  observacoes: z.string().max(500).default(""),
  aprovacaoIA: z.boolean().refine((v) => v, { message: "Confirme a aprovação." }),
});

const stepDefinitions = [
  { id: 1, title: "Selecionar template", description: "Escolha a estrutura base do plano." },
  { id: 2, title: "Dados da turma", description: "Defina turma, etapa, componente e volume de aulas." },
  { id: 3, title: "Contexto e BNCC", description: "Informe contexto pedagógico, objetivos, BNCC e SAEB." },
  { id: 4, title: "Aprovação da IA", description: "Revise os dados e libere a geração." },
] as const;

const stepFields: Array<Array<keyof GerarPlanoWizardValues>> = [
  ["templateId"],
  ["nomeTurma", "etapaEnsino", "anoSerie", "componenteCurricular", "quantidadeAulas"],
  ["contextoTurma", "objetivoGeral", "habilidadesBncc", "referenciaSaeb", "observacoes"],
  ["aprovacaoIA"],
];

function getManualFields(schema: TemplateFieldSchema[]): TemplateFieldSchema[] {
  return schema.filter((c) => c.role === "manual" || c.group === "dados_turma" || !c.role);
}

function getIaFields(schema: TemplateFieldSchema[]): TemplateFieldSchema[] {
  return schema.filter((c) => c.role === "ia_sugerida");
}

function isDynamicMode(template: TemplateOption | null): boolean {
  const schema = template?.schema_campos ?? [];
  if (schema.length === 0) return false;
  return schema.some((c) => c.role === "manual" || c.role === "ia_sugerida");
}

interface PlanGenerationWizardProps {
  userId: string;
  userName: string;
  availableTemplates: TemplateOption[];
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium" }).format(new Date(value));
}

function getErrorMessage(error: string | undefined) {
  if (!error) return null;
  return <p className="mt-2 text-sm font-medium text-rose-600">{error}</p>;
}

export function PlanGenerationWizard({
  userId,
  userName,
  availableTemplates,
}: PlanGenerationWizardProps) {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [iaLoading, setIaLoading] = useState(false);
  const [iaError, setIaError] = useState<string | null>(null);
  const [iaSuggestions, setIaSuggestions] = useState<Record<string, IaSugestao[]> | Record<string, unknown> | null>(null);
  const [iaSelections, setIaSelections] = useState<Record<string, string[]>>({});
  const [dynamicManualValues, setDynamicManualValues] = useState<Record<string, string | number>>({});

  const form = useForm<GerarPlanoWizardValues>({
    resolver: zodResolver(wizardSchema),
    mode: "onTouched",
    defaultValues: {
      templateId: availableTemplates[0]?.id ?? "",
      nomeTurma: "",
      etapaEnsino: "Ensino Fundamental",
      anoSerie: "",
      componenteCurricular: "",
      quantidadeAulas: 4,
      contextoTurma: "",
      objetivoGeral: "",
      habilidadesBncc: "",
      referenciaSaeb: "",
      observacoes: "",
      aprovacaoIA: false,
    },
  });

  const selectedTemplateId = form.watch("templateId");
  const watchedValues = form.watch();
  const selectedTemplate = availableTemplates.find((t) => t.id === selectedTemplateId) ?? null;
  const schema = selectedTemplate?.schema_campos ?? [];
  const dynamicMode = isDynamicMode(selectedTemplate);
  const manualFields = getManualFields(schema);
  const iaFields = getIaFields(schema);

  useEffect(() => {
    setIaSuggestions(null);
    setIaSelections({});
    setIaError(null);
    setDynamicManualValues({});
  }, [selectedTemplateId]);

  function handleNextStep() {
    const fieldsToValidate = stepFields[currentStep];
    if (fieldsToValidate) {
      void form.trigger(fieldsToValidate, { shouldFocus: true }).then((ok) => {
        if (ok) setCurrentStep((s) => Math.min(s + 1, stepDefinitions.length - 1));
      });
    } else {
      setCurrentStep((s) => Math.min(s + 1, stepDefinitions.length - 1));
    }
  }

  function toggleIaSelection(fieldKey: string, id: string) {
    setIaSelections((prev) => {
      const arr = prev[fieldKey] ?? [];
      const next = arr.includes(id) ? arr.filter((x) => x !== id) : [...arr, id];
      return { ...prev, [fieldKey]: next };
    });
  }

  async function handleGerarSugestoes() {
    setIaError(null);
    setIaSuggestions(null);
    setIaSelections({});

    const valid = await form.trigger(stepFields.flat(), { shouldFocus: true });
    if (!valid) return;

    const values = form.getValues();
    const dadosManuais = dynamicMode
      ? { ...dynamicManualValues, ...values }
      : {
          nome_turma: values.nomeTurma,
          etapa_ensino: values.etapaEnsino,
          ano_serie: values.anoSerie,
          componente_curricular: values.componenteCurricular,
          quantidade_aulas: values.quantidadeAulas,
          contexto_turma: values.contextoTurma,
          objetivo_geral: values.objetivoGeral,
          habilidades_bncc: values.habilidadesBncc,
          referencia_saeb: values.referenciaSaeb,
        };

    try {
      setIaLoading(true);
      const res = await fetch("/api/gerar-plano", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          templateId: values.templateId,
          diretriz: "BNCC",
          dadosManuais,
          camposIaSugerida: iaFields.length > 0 ? iaFields : undefined,
          ...(dynamicMode ? {} : {
            contextoTurma: dadosManuais.contexto_turma ?? "",
            objetivos: dadosManuais.objetivo_geral ?? "",
            preferencias: dadosManuais.referencia_saeb ?? "",
          }),
        }),
      });

      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: string } | null;
        throw new Error(data?.error ?? "Falha ao gerar sugestões.");
      }

      const data = (await res.json()) as { sugestoes?: Record<string, IaSugestao[]>; conteudo?: unknown };
      setIaSuggestions(data.sugestoes ?? (typeof data.conteudo === "object" && data.conteudo !== null && !Array.isArray(data.conteudo) ? (data.conteudo as Record<string, IaSugestao[]>) : null));
    } catch (err) {
      setIaError(err instanceof Error ? err.message : "Erro ao chamar a IA.");
    } finally {
      setIaLoading(false);
    }
  }

  async function persistPlano(values: GerarPlanoWizardValues) {
    const conteudo: Record<string, unknown> = {
      criado_por: userName,
      template: selectedTemplate,
      dados_turma: dynamicMode
        ? dynamicManualValues
        : {
            nome_turma: values.nomeTurma,
            etapa_ensino: values.etapaEnsino,
            ano_serie: values.anoSerie,
            componente_curricular: values.componenteCurricular,
            quantidade_aulas: values.quantidadeAulas,
          },
      contexto_bncc: dynamicMode
        ? {}
        : {
            contexto_turma: values.contextoTurma,
            objetivo_geral: values.objetivoGeral,
            habilidades_bncc: values.habilidadesBncc?.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean) ?? [],
            referencia_saeb: values.referenciaSaeb,
            observacoes: values.observacoes,
          },
    };

    if (dynamicMode && iaSuggestions && Object.keys(iaSelections).length > 0) {
      const iaPreenchido: Record<string, IaSugestao[]> = {};
      for (const [key, ids] of Object.entries(iaSelections)) {
        if (ids.length === 0) continue;
        const sugestoes = (iaSuggestions as Record<string, IaSugestao[]>)[key] ?? [];
        iaPreenchido[key] = sugestoes.filter((s: IaSugestao) => ids.includes(s.id));
      }
      conteudo.sugestoes_ia_selecionadas = iaPreenchido;
    }

    await planosService.createPlano({
      user_id: userId,
      template_id: values.templateId,
      status: "aguardando_geracao",
      conteudo_gerado: conteudo,
    });

    router.push("/dashboard?plano=criado");
    router.refresh();
  }

  const handleSubmit = form.handleSubmit((values) => {
    setSubmitError(null);
    startTransition(() => {
      void persistPlano(values).catch((err) => {
        setSubmitError(err instanceof Error ? err.message : "Falha ao salvar.");
      });
    });
  });

  const steps = dynamicMode && manualFields.length > 0 && iaFields.length > 0
    ? [
        { id: 1, title: "Selecionar template", description: "Escolha o modelo base." },
        { id: 2, title: "Dados da turma", description: "Preencha os campos manuais." },
        { id: 3, title: "Sugestões da IA", description: "Marque as opções sugeridas pela IA." },
        { id: 4, title: "Revisar e salvar", description: "Confirme e salve o plano." },
      ]
    : stepDefinitions;

  return (
    <div className="space-y-8">
      <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-600">Wizard de geração</p>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">Novo plano orientado por IA</h2>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">
          {dynamicMode
            ? "Os campos são gerados automaticamente a partir do template escolhido."
            : "O wizard prepara o payload pedagógico para o Gemini."}
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        {steps.map((step, index) => {
          const isCompleted = index < currentStep;
          const isCurrent = index === currentStep;
          return (
            <div
              key={step.id}
              className={`rounded-3xl border p-4 transition ${
                isCurrent ? "border-slate-950 bg-slate-950 text-white" : isCompleted ? "border-emerald-200 bg-emerald-50 text-emerald-950" : "border-slate-200 bg-white text-slate-600"
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <span className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold ${isCurrent ? "bg-white/10" : isCompleted ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-700"}`}>
                  {isCompleted ? <Check className="h-4 w-4" /> : step.id}
                </span>
                <span className="text-xs font-medium uppercase tracking-[0.16em]">{isCurrent ? "Em edição" : isCompleted ? "Concluído" : "Pendente"}</span>
              </div>
              <h3 className="mt-4 text-base font-semibold">{step.title}</h3>
              <p className="mt-2 text-sm leading-6 opacity-90">{step.description}</p>
            </div>
          );
        })}
      </div>

      <form className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm" onSubmit={handleSubmit}>
        {currentStep === 0 && (
          <section>
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-amber-50 p-3 text-amber-600">
                <BookCheck className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-slate-950">Escolha o template base</h3>
                <p className="text-sm text-slate-600">Selecione o documento que define a estrutura final do plano.</p>
              </div>
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {availableTemplates.map((template) => {
                const isSelected = template.id === selectedTemplateId;
                return (
                  <button
                    key={template.id}
                    type="button"
                    onClick={() => form.setValue("templateId", template.id, { shouldDirty: true, shouldValidate: true })}
                    className={`rounded-3xl border p-5 text-left transition ${isSelected ? "border-emerald-500 bg-emerald-50 shadow-sm" : "border-slate-200 bg-white hover:border-slate-300"}`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h4 className="text-lg font-semibold text-slate-950">{template.nome}</h4>
                        <p className="mt-2 text-sm leading-6 text-slate-600">
                          {template.campoCount} campos · {isDynamicMode(template) ? "dinâmico" : "padrão"}
                        </p>
                      </div>
                      <span className={`flex h-10 w-10 items-center justify-center rounded-2xl ${isSelected ? "bg-emerald-600 text-white" : "bg-slate-100 text-slate-500"}`}>
                        <Check className="h-4 w-4" />
                      </span>
                    </div>
                    <p className="mt-4 text-xs font-medium uppercase tracking-[0.16em] text-slate-500">Criado em {formatDate(template.criadoEm)}</p>
                  </button>
                );
              })}
            </div>
            {getErrorMessage(form.formState.errors.templateId?.message)}
          </section>
        )}

        {currentStep === 1 && (
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-sky-50 p-3 text-sky-600">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-slate-950">Dados da turma</h3>
                <p className="text-sm text-slate-600">Preencha os campos manuais do template.</p>
              </div>
            </div>

            {dynamicMode && manualFields.length > 0 ? (
              <div className="grid gap-5 md:grid-cols-2">
                {manualFields.map((field) => (
                  <label key={field.key} className="block">
                    <span className="text-sm font-medium text-slate-700">{field.label}</span>
                    {field.type === "textarea" ? (
                      <textarea
                        value={(dynamicManualValues[field.key] as string) ?? ""}
                        onChange={(e) => setDynamicManualValues((p) => ({ ...p, [field.key]: e.target.value }))}
                        rows={4}
                        className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-950 outline-none focus:border-slate-950"
                        placeholder={field.placeholder}
                      />
                    ) : field.type === "number" ? (
                      <input
                        type="number"
                        value={(dynamicManualValues[field.key] as number) ?? ""}
                        onChange={(e) => setDynamicManualValues((p) => ({ ...p, [field.key]: Number(e.target.value) || 0 }))}
                        className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-950 outline-none focus:border-slate-950"
                      />
                    ) : (
                      <input
                        type="text"
                        value={(dynamicManualValues[field.key] as string) ?? ""}
                        onChange={(e) => setDynamicManualValues((p) => ({ ...p, [field.key]: e.target.value }))}
                        className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-950 outline-none focus:border-slate-950"
                        placeholder={field.placeholder}
                      />
                    )}
                  </label>
                ))}
              </div>
            ) : (
              <div className="grid gap-5 md:grid-cols-2">
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Turma</span>
                  <input {...form.register("nomeTurma")} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: 5º ano B" />
                  {getErrorMessage(form.formState.errors.nomeTurma?.message)}
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Etapa de ensino</span>
                  <select {...form.register("etapaEnsino")} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950">
                    {etapasEnsino.map((o) => (
                      <option key={o} value={o}>{o}</option>
                    ))}
                  </select>
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Ano ou série</span>
                  <input {...form.register("anoSerie")} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: 5º ano" />
                  {getErrorMessage(form.formState.errors.anoSerie?.message)}
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Componente curricular</span>
                  <input {...form.register("componenteCurricular")} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: Língua Portuguesa" />
                  {getErrorMessage(form.formState.errors.componenteCurricular?.message)}
                </label>
                <label className="block md:col-span-2">
                  <span className="text-sm font-medium text-slate-700">Quantidade de aulas</span>
                  <input type="number" min={1} max={20} {...form.register("quantidadeAulas", { valueAsNumber: true })} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" />
                  {getErrorMessage(form.formState.errors.quantidadeAulas?.message)}
                </label>
              </div>
            )}
          </section>
        )}

        {currentStep === 2 && (
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-violet-50 p-3 text-violet-600">
                <WandSparkles className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-slate-950">Contexto pedagógico e sugestões da IA</h3>
                <p className="text-sm text-slate-600">
                  {dynamicMode && iaFields.length > 0
                    ? "Clique em Gerar sugestões e marque as opções que deseja usar."
                    : "Informe contexto, objetivos, BNCC e SAEB."}
                </p>
              </div>
            </div>

            {dynamicMode && iaFields.length > 0 ? (
              <div className="space-y-6">
                <button
                  type="button"
                  onClick={() => void handleGerarSugestoes()}
                  disabled={iaLoading || isPending}
                  className="inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-60"
                >
                  {iaLoading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  Gerar sugestões com IA
                </button>
                {!iaSuggestions && !iaLoading && (
                  <p className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center text-sm text-slate-600">
                    Clique em &quot;Gerar sugestões com IA&quot; acima para ver as opções pedagógicas baseadas no template e nos dados informados.
                  </p>
                )}
                {iaError && <p className="text-sm text-rose-600">{iaError}</p>}
                {iaSuggestions && typeof iaSuggestions === "object" && !Array.isArray(iaSuggestions) && iaFields.every((f) => Array.isArray((iaSuggestions as Record<string, unknown>)[f.key])) && (
                  <div className="space-y-6">
                    {iaFields.map((field) => {
                      const sugestoes = ((iaSuggestions as Record<string, IaSugestao[]>)[field.key] ?? []);
                      const selected = iaSelections[field.key] ?? [];
                      if (sugestoes.length === 0) return null;
                      return (
                        <div key={field.key} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                          <p className="text-sm font-semibold text-slate-900">{field.label}</p>
                          <p className="mt-1 text-xs text-slate-500">Marque as opções que deseja incluir no plano.</p>
                          <div className="mt-3 space-y-2">
                            {sugestoes.map((s) => (
                              <label key={s.id} className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 bg-white p-3 transition hover:border-slate-300">
                                <input
                                  type="checkbox"
                                  checked={selected.includes(s.id)}
                                  onChange={() => toggleIaSelection(field.key, s.id)}
                                  className="mt-1 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                                />
                                <div>
                                  <span className="text-sm font-medium text-slate-900">{s.label}</span>
                                  {s.fonte && <span className="ml-2 text-xs text-slate-500">({s.fonte})</span>}
                                  {s.descricao && <p className="mt-1 text-xs text-slate-600">{s.descricao}</p>}
                                </div>
                              </label>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-5">
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Contexto da turma</span>
                  <textarea {...form.register("contextoTurma")} rows={5} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Descreva perfil da turma, desafios, repertório prévio." />
                  {getErrorMessage(form.formState.errors.contextoTurma?.message)}
                </label>
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Objetivo geral</span>
                  <textarea {...form.register("objetivoGeral")} rows={4} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: Desenvolver leitura inferencial." />
                  {getErrorMessage(form.formState.errors.objetivoGeral?.message)}
                </label>
                <div className="grid gap-5 md:grid-cols-2">
                  <label className="block">
                    <span className="text-sm font-medium text-slate-700">Códigos BNCC</span>
                    <textarea {...form.register("habilidadesBncc")} rows={4} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: EF05LP05, EF05LP06" />
                    {getErrorMessage(form.formState.errors.habilidadesBncc?.message)}
                  </label>
                  <label className="block">
                    <span className="text-sm font-medium text-slate-700">Referência SAEB</span>
                    <textarea {...form.register("referenciaSaeb")} rows={4} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" placeholder="Ex.: Matriz SAEB de leitura." />
                    {getErrorMessage(form.formState.errors.referenciaSaeb?.message)}
                  </label>
                </div>
                <label className="block">
                  <span className="text-sm font-medium text-slate-700">Observações</span>
                  <textarea {...form.register("observacoes")} rows={3} className="mt-2 w-full rounded-2xl border border-slate-300 px-4 py-3 text-sm outline-none focus:border-slate-950" />
                </label>
              </div>
            )}
          </section>
        )}

        {currentStep === 3 && (
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-600">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-slate-950">Revisão e aprovação</h3>
                <p className="text-sm text-slate-600">Revise os dados antes de salvar o plano.</p>
              </div>
            </div>

            <div className="grid gap-5 xl:grid-cols-[1.4fr_1fr]">
              <div className="space-y-5 rounded-3xl border border-slate-200 bg-slate-50 p-5">
                <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Template</p>
                <p className="text-lg font-semibold text-slate-950">{selectedTemplate?.nome ?? "Não definido"}</p>
                {dynamicMode && Object.keys(dynamicManualValues).length > 0 && (
                  <div className="space-y-3">
                    {manualFields.map((f) => (
                      <div key={f.key}>
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">{f.label}</p>
                        <p className="mt-1 text-sm text-slate-900">{String(dynamicManualValues[f.key] ?? "-")}</p>
                      </div>
                    ))}
                  </div>
                )}
                {!dynamicMode && (
                  <>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div><p className="text-xs font-semibold uppercase text-slate-500">Turma</p><p className="mt-1 text-sm text-slate-900">{watchedValues.nomeTurma}</p></div>
                      <div><p className="text-xs font-semibold uppercase text-slate-500">Etapa</p><p className="mt-1 text-sm text-slate-900">{watchedValues.etapaEnsino}</p></div>
                      <div><p className="text-xs font-semibold uppercase text-slate-500">Ano</p><p className="mt-1 text-sm text-slate-900">{watchedValues.anoSerie}</p></div>
                      <div><p className="text-xs font-semibold uppercase text-slate-500">Componente</p><p className="mt-1 text-sm text-slate-900">{watchedValues.componenteCurricular}</p></div>
                    </div>
                    <div><p className="text-xs font-semibold uppercase text-slate-500">Contexto</p><p className="mt-1 text-sm text-slate-900">{watchedValues.contextoTurma}</p></div>
                    <div><p className="text-xs font-semibold uppercase text-slate-500">Objetivo</p><p className="mt-1 text-sm text-slate-900">{watchedValues.objetivoGeral}</p></div>
                    <div><p className="text-xs font-semibold uppercase text-slate-500">BNCC</p><p className="mt-1 text-sm text-slate-900">{watchedValues.habilidadesBncc || "-"}</p></div>
                    <div><p className="text-xs font-semibold uppercase text-slate-500">SAEB</p><p className="mt-1 text-sm text-slate-900">{watchedValues.referenciaSaeb}</p></div>
                  </>
                )}
                {dynamicMode && Object.keys(iaSelections).length > 0 && iaSuggestions && typeof iaSuggestions === "object" && !Array.isArray(iaSuggestions) && (
                  <div className="space-y-3">
                    <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Sugestões selecionadas</p>
                    {Object.entries(iaSelections).map(([key, ids]) => {
                      const sugestoes = ((iaSuggestions as Record<string, IaSugestao[]>)[key] ?? []).filter((s) => ids.includes(s.id));
                      if (sugestoes.length === 0) return null;
                      const field = iaFields.find((f) => f.key === key);
                      return (
                        <div key={key}>
                          <p className="text-xs font-semibold text-slate-500">{field?.label ?? key}</p>
                          <ul className="mt-1 list-inside list-disc text-sm text-slate-900">
                            {sugestoes.map((s) => <li key={s.id}>{s.label}</li>)}
                          </ul>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="space-y-5">
                {!dynamicMode && (
                  <div className="flex flex-col gap-3">
                    <button
                      type="button"
                      onClick={() => void handleGerarSugestoes()}
                      disabled={iaLoading || isPending}
                      className="inline-flex w-fit items-center gap-2 rounded-2xl border border-slate-300 px-4 py-3 text-sm font-medium text-slate-800 transition hover:border-slate-950"
                    >
                      {iaLoading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                      Gerar sugestões com IA
                    </button>
                    {iaError && <p className="text-sm text-rose-600">{iaError}</p>}
                    {iaSuggestions != null && (
                      <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
                        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-emerald-700">Sugestões da IA (pré-visualização)</p>
                        <pre className="mt-2 max-h-64 overflow-auto whitespace-pre-wrap break-words text-xs text-emerald-950">
                          {JSON.stringify(iaSuggestions, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
                <label className="flex items-start gap-3 rounded-3xl border border-slate-200 bg-white p-5">
                  <input type="checkbox" {...form.register("aprovacaoIA")} className="mt-1 h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600" />
                  <span>
                    <span className="block text-sm font-medium text-slate-900">Confirmo que os dados foram revisados.</span>
                    <span className="mt-1 block text-sm text-slate-600">O plano será salvo com status aguardando_geracao.</span>
                  </span>
                </label>
                {getErrorMessage(form.formState.errors.aprovacaoIA?.message)}
                {submitError && <p className="text-sm text-rose-600">{submitError}</p>}
              </div>
            </div>
          </section>
        )}

        <div className="mt-8 flex flex-col gap-3 border-t border-slate-200 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <button
            type="button"
            onClick={() => setCurrentStep((s) => Math.max(s - 1, 0))}
            disabled={currentStep === 0 || isPending}
            className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 px-4 py-3 text-sm font-medium text-slate-700 transition hover:border-slate-950 hover:text-slate-950 disabled:opacity-50"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar
          </button>
          {currentStep < steps.length - 1 ? (
            <button
              type="button"
              onClick={() => void handleNextStep()}
              disabled={isPending}
              className="inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-50"
            >
              Continuar
              <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={isPending}
              className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-emerald-500 disabled:opacity-50"
            >
              {isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              Aprovar e salvar plano
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
