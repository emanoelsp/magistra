# PlanoMestre

SaaS para professores gerarem Planos de Ensino Anual, Planos de Aula e Sequências Didáticas baseados em templates (PDF/DOCX) customizados pelas escolas, integrados com BNCC, SAEB e CTBC.

## Stack

- **Framework:** Next.js 15 (App Router) + React 19
- **Estilização:** Tailwind CSS
- **Autenticação e Banco:** Firebase Auth + Firestore
- **IA:** Google Gemini API (@google/generative-ai)
- **PDF:** pdf-lib (geração de documentos)

## Regras de Negócio

1. **Templates:** Upload de PDF/DOCX, salvos na lista. A IA (Gemini) extrai os campos automaticamente.
2. **Wizard:** Extrai campos do template e exibe como inputs.
3. **Campos manuais:** Dados da escola, turma, disciplina, professor — preenchidos pelo usuário.
4. **Campos pedagógicos:** BNCC, SAEB, CTBC, competências, habilidades — sugestões da IA conforme ano e disciplina.
5. **Finalização:** Plano no mesmo formato do template, preenchido e disponível para download em PDF.

## Estrutura

```
app/
  page.tsx                 # Landing
  login/page.tsx           # Login/Cadastro
  dashboard/
    layout.tsx             # Layout com Sidebar
    page.tsx               # Visão geral
    templates/page.tsx      # Upload e lista de templates
    gerar/page.tsx         # Wizard de geração
    historico/page.tsx     # Histórico de planos
    perfil/page.tsx        # Perfil e assinatura
  api/
    session/route.ts       # Sessão Firebase
    logout/route.ts        # Logout
    templates/introspect/   # Extração de campos do PDF
    gerar-plano/route.ts   # Geração com Gemini
    planos/[id]/download/  # Download PDF
lib/
  firebase/                # Client e Admin
  auth/session.ts          # Sessão e perfil
  types/firestore.ts       # Tipos
  services/firestore/      # Templates, Planos, Dashboard
components/
  layout/Sidebar.tsx
  templates/               # Uploader, Lista
  planos/                  # Wizard
```

## Configuração

### 1. Variáveis de ambiente

Copie `.env.local.example` para `.env.local` e preencha:

```bash
cp .env.local.example .env.local
```

**Obrigatórias:**

- `GOOGLE_GEMINI_API_KEY` — Chave da API Gemini
- `NEXT_PUBLIC_FIREBASE_*` — Config do Firebase Web
- `FIREBASE_ADMIN_*` — Service Account do Firebase Admin

### 2. Firebase

1. Crie um projeto no [Firebase Console](https://console.firebase.google.com).
2. Ative **Authentication** (Email/Password).
3. Crie o **Firestore**.
4. Gere uma **Service Account** em Configurações do projeto → Contas de serviço.
5. Cole a chave privada em `FIREBASE_ADMIN_PRIVATE_KEY` (entre aspas, em uma linha).

### 3. Regras do Firestore

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /templates/{docId} {
      allow read, write: if request.auth != null;
    }
    match /planos/{docId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Execução

```bash
npm install
npm run dev
```

Acesse [http://localhost:3000](http://localhost:3000).

## Fluxo do Usuário

1. **Landing** → Login/Cadastro
2. **Dashboard** → Visão geral (estatísticas)
3. **Meus Templates** → Upload PDF/DOCX → IA extrai campos → Template salvo
4. **Gerar Plano** → Escolher template → Preencher dados manuais → Gerar sugestões IA → Revisar → Salvar
5. **Histórico** → Ver planos → Baixar PDF
6. **Perfil** → Dados e assinatura

## Configuração do Gemini (Anti-Alucinação)

- **Modelo:** gemini-1.5-flash (ou gemini-1.5-pro)
- **Parâmetros:** temperature: 0.1, topP: 0.6, topK: 40
- **Response:** application/json
- **System Instruction:** Assistente educacional rigoroso, dados reais BNCC/SAEB/CTBC, nunca inventar códigos.

## Licença

Projeto privado.
