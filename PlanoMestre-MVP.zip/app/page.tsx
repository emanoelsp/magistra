import Link from "next/link";
import { ArrowRight, BookCheck, FileText, Sparkles, Upload, Check } from "lucide-react";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-50">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-6 py-20 sm:py-28">
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-emerald-600">PlanoMestre</p>
          <h1 className="mt-4 text-balance text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
            Automatize a burocracia escolar
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
            Gere Planos de Ensino Anual, Planos de Aula e Sequências Didáticas em minutos.
            Use templates da sua escola, integrados com BNCC, SAEB e CTBC.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-6 py-4 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Começar agora
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-medium text-slate-900 transition hover:border-slate-300"
            >
              Já tenho conta
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="text-center text-2xl font-bold tracking-tight text-slate-950 sm:text-3xl">
          Tudo que você precisa para planejar
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-slate-600">
          Templates customizados, sugestões de IA e exportação em PDF.
        </p>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: Upload,
              title: "Upload de templates",
              desc: "Envie PDF ou DOCX da sua escola. A IA extrai os campos automaticamente.",
            },
            {
              icon: FileText,
              title: "Formulário dinâmico",
              desc: "Campos preenchidos manualmente (turma, disciplina) e sugestões IA (BNCC, SAEB).",
            },
            {
              icon: Sparkles,
              title: "Assistente pedagógico",
              desc: "Sugestões baseadas em dados reais. Nenhum código BNCC inventado.",
            },
            {
              icon: BookCheck,
              title: "Download em PDF",
              desc: "Plano final no mesmo formato do template, pronto para imprimir.",
            },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition hover:border-slate-300"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-600 text-white">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-slate-950">{item.title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-600">{item.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Como funciona */}
      <section className="border-t border-slate-200 bg-white py-16">
        <div className="mx-auto max-w-6xl px-6">
          <h2 className="text-center text-2xl font-bold tracking-tight text-slate-950 sm:text-3xl">
            Como funciona
          </h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-950 text-white font-bold">1</span>
              <h3 className="mt-4 text-lg font-semibold text-slate-950">Upload</h3>
              <p className="mt-2 text-sm text-slate-600">
                Envie o template (PDF/DOCX) da sua escola. A IA analisa e extrai os campos.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-950 text-white font-bold">2</span>
              <h3 className="mt-4 text-lg font-semibold text-slate-950">Edição</h3>
              <p className="mt-2 text-sm text-slate-600">
                Preencha dados da turma, disciplina e ano. A IA sugere BNCC, SAEB e CTBC.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-950 text-white font-bold">3</span>
              <h3 className="mt-4 text-lg font-semibold text-slate-950">Geração</h3>
              <p className="mt-2 text-sm text-slate-600">
                Revise, aprove e baixe o plano em PDF no formato do template.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Preços */}
      <section className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="text-center text-2xl font-bold tracking-tight text-slate-950 sm:text-3xl">
          Planos e preços
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-center text-slate-600">
          Escolha o plano ideal para sua necessidade.
        </p>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {[
            {
              name: "Starter",
              price: "R$ 19,90",
              period: "/mês",
              features: ["5 planos/mês", "3 templates", "Sugestões BNCC"],
              cta: "Começar",
              highlight: false,
            },
            {
              name: "Pro",
              price: "R$ 49,90",
              period: "/mês",
              features: ["20 planos/mês", "10 templates", "BNCC + SAEB + CTBC", "Suporte prioritário"],
              cta: "Assinar Pro",
              highlight: true,
            },
            {
              name: "Escola",
              price: "R$ 149,90",
              period: "/mês",
              features: ["Planos ilimitados", "Templates ilimitados", "Toda a equipe", "Suporte dedicado"],
              cta: "Falar com vendas",
              highlight: false,
            },
          ].map((plan) => (
            <div
              key={plan.name}
              className={`rounded-3xl border p-6 ${
                plan.highlight ? "border-emerald-500 bg-emerald-50 shadow-lg" : "border-slate-200 bg-white"
              }`}
            >
              <h3 className="text-lg font-semibold text-slate-950">{plan.name}</h3>
              <p className="mt-2 text-3xl font-bold text-slate-950">
                {plan.price}
                <span className="text-xs font-normal text-slate-500">{plan.period}</span>
              </p>
              <ul className="mt-6 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-slate-700">
                    <Check className="h-4 w-4 shrink-0 text-emerald-600" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/login"
                className={`mt-6 block w-full rounded-2xl border px-4 py-3 text-center text-sm font-medium transition ${
                  plan.highlight
                    ? "border-emerald-600 bg-emerald-600 text-white hover:bg-emerald-700"
                    : "border-slate-300 bg-white text-slate-900 hover:border-slate-950"
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* CTA final */}
      <section className="border-t border-slate-200 bg-slate-950 py-16">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
            Pronto para automatizar a burocracia?
          </h2>
          <p className="mt-4 text-slate-300">
            Comece agora e gere seu primeiro plano em minutos.
          </p>
          <Link
            href="/login"
            className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-4 text-sm font-medium text-slate-950 transition hover:bg-slate-100"
          >
            Criar conta gratuitamente
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </main>
  );
}
