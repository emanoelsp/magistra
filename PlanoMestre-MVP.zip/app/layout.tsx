import "./globals.css";

import type { Metadata } from "next";
import type { ReactNode } from "react";

export const metadata: Metadata = {
  title: "PlanoMestre",
  description: "SaaS para geração de planos de ensino e sequências didáticas alinhadas à BNCC e SAEB.",
};

interface RootLayoutProps {
  children: ReactNode;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="pt-BR">
      <body className="bg-slate-50 text-slate-950 antialiased">{children}</body>
    </html>
  );
}
