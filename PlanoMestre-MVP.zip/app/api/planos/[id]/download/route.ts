import "server-only";

import { NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

import { getAdminDb } from "../../../../../lib/firebase/admin";
import type { PlanoRecord, TemplateRecord } from "../../../../../lib/types/firestore";

function flattenObject(obj: Record<string, unknown>, prefix = ""): Array<{ key: string; value: string }> {
  const result: Array<{ key: string; value: string }> = [];

  for (const [k, v] of Object.entries(obj)) {
    const fullKey = prefix ? `${prefix}.${k}` : k;

    if (v === null || v === undefined) {
      continue;
    }

    if (typeof v === "object" && !Array.isArray(v) && v !== null && !(v instanceof Date)) {
      const nested = flattenObject(v as Record<string, unknown>, fullKey);
      result.push(...nested);
    } else if (Array.isArray(v)) {
      const arrStr = v
        .map((item) => (typeof item === "object" && item !== null && "label" in item ? (item as { label?: string }).label : String(item)))
        .filter(Boolean)
        .join("\n• ");
      result.push({ key: fullKey, value: arrStr ? `• ${arrStr}` : "-" });
    } else {
      result.push({ key: fullKey, value: String(v) });
    }
  }

  return result;
}

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;

    if (!id) {
      return NextResponse.json({ error: "ID do plano é obrigatório." }, { status: 400 });
    }

    const db = getAdminDb();
    const planoSnap = await db.collection("planos").doc(id).get();

    if (!planoSnap.exists) {
      return NextResponse.json({ error: "Plano não encontrado." }, { status: 404 });
    }

    const planoData = planoSnap.data() as PlanoRecord;
    const conteudo = (planoData.conteudo_gerado ?? {}) as Record<string, unknown>;

    const templateSnap = await db.collection("templates").doc(planoData.template_id).get();
    const template = templateSnap.exists ? (templateSnap.data() as TemplateRecord) : null;
    const templateNome = template?.nome ?? "Plano";

    const pdfDoc = await PDFDocument.create();
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    const page = pdfDoc.addPage([595, 842]);
    const { width, height } = page.getSize();
    const margin = 50;
    let y = height - margin;

    const title = `${templateNome} - Gerado em ${new Date().toLocaleDateString("pt-BR")}`;
  page.drawText(title, {
    x: margin,
    y,
    size: 16,
    font: fontBold,
    color: rgb(0.1, 0.1, 0.1),
  });
  y -= 28;

  const entries = flattenObject(conteudo);
  let currentPage = page;

  for (const { key, value } of entries) {
    const label = key
      .replace(/_/g, " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());
    const lines = value.split("\n");
    const blockHeight = lines.length * 14 + 20;

    if (y < margin + blockHeight) {
      const newPage = pdfDoc.addPage([595, 842]);
      y = newPage.getHeight() - margin;
      currentPage = newPage;
    }

    currentPage.drawText(label + ":", {
      x: margin,
      y,
      size: 10,
      font: fontBold,
      color: rgb(0.2, 0.2, 0.2),
    });
    y -= 14;

    for (const line of lines) {
      const wrapped = line.length > 90 ? line.match(/.{1,90}(\s|$)/g) ?? [line] : [line];
      for (const seg of wrapped) {
        currentPage.drawText(seg.trim(), {
          x: margin + 5,
          y,
          size: 9,
          font,
          color: rgb(0.3, 0.3, 0.3),
        });
        y -= 12;
      }
    }
    y -= 8;
  }

  const pdfBytes = await pdfDoc.save();

  return new NextResponse(new Blob([new Uint8Array(pdfBytes)]), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="plano-${id.slice(0, 8)}.pdf"`,
      "Content-Length": String(pdfBytes.length),
    },
  });
  } catch (error) {
    console.error("Erro ao gerar PDF:", error);
    return NextResponse.json({ error: "Falha ao gerar PDF." }, { status: 500 });
  }
}
