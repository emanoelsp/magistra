import "server-only";

import { NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";

import { getAdminDb } from "../../../lib/firebase/admin";
import type { IaSugestao, TemplateFieldSchema, TemplateRecord } from "../../../lib/types/firestore";

const MODEL_NAME = "gemini-1.5-flash";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      templateId,
      diretriz,
      dadosManuais,
      camposIaSugerida,
      contextoTurma,
      objetivos,
      preferencias,
    } = body ?? {};

    if (typeof templateId !== "string" || !templateId) {
      return NextResponse.json({ error: "templateId é obrigatório." }, { status: 400 });
    }

    const db = getAdminDb();
    const snapshot = await db.collection("templates").doc(templateId).get();

    if (!snapshot.exists) {
      return NextResponse.json({ error: "Template não encontrado." }, { status: 404 });
    }

    const template = snapshot.data() as TemplateRecord;
    const schemaCampos = Array.isArray(template.schema_campos) ? template.schema_campos : [];
    const iaFields: TemplateFieldSchema[] = Array.isArray(camposIaSugerida)
      ? camposIaSugerida
      : schemaCampos.filter((c) => (c as { role?: string }).role === "ia_sugerida");

    const useLegacyFormat = iaFields.length === 0 && (contextoTurma != null || objetivos != null);

    const apiKey = process.env.GOOGLE_GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: "GOOGLE_GEMINI_API_KEY não configurada." }, { status: 500 });
    }

    const genAI = new GoogleGenerativeAI(apiKey);

    if (useLegacyFormat) {
      const model = genAI.getGenerativeModel({
        model: MODEL_NAME,
        generationConfig: { temperature: 0.1, topP: 0.6, topK: 40, responseMimeType: "application/json" },
        systemInstruction:
          "Você é um assistente educacional rigoroso. Preencha o JSON com sugestões baseadas APENAS em dados " +
          "pedagógicos reais (BNCC, SAEB, CTBC). NUNCA invente códigos BNCC. Retorne SOMENTE um JSON válido.",
      });
      const payload = {
        templateNome: template.nome,
        schemaCampos: template.schema_campos,
        diretriz: diretriz ?? "BNCC",
        contextoTurma: contextoTurma ?? null,
        objetivos: objetivos ?? null,
        preferencias: preferencias ?? null,
      };
      const userPrompt = "Preencha o JSON com sugestões alinhadas à diretriz.\n\n" + JSON.stringify(payload);
      const response = await model.generateContent(userPrompt);
      const rawText = response.response.text();
      let parsed: unknown;
      try {
        parsed = JSON.parse(rawText);
      } catch {
        const fb = rawText.indexOf("{");
        const lb = rawText.lastIndexOf("}");
        parsed = fb >= 0 && lb > fb ? JSON.parse(rawText.slice(fb, lb + 1)) : {};
      }
      return NextResponse.json({ conteudo: parsed, sugestoes: null });
    }

    const model = genAI.getGenerativeModel({
      model: MODEL_NAME,
      generationConfig: {
        temperature: 0.1,
        topP: 0.6,
        topK: 40,
        responseMimeType: "application/json",
      },
      systemInstruction:
        "Você é um assistente educacional rigoroso. Para cada campo solicitado, retorne um array de sugestões " +
        "no formato { id, label, descricao?, fonte? }. Use APENAS dados pedagógicos reais (BNCC, SAEB, CTBC). " +
        "NUNCA invente códigos BNCC. Retorne SOMENTE um JSON com as chaves dos campos e arrays de sugestões.",
    });

    const payload = {
      templateNome: template.nome,
      diretriz: diretriz ?? "BNCC",
      dadosManuais: dadosManuais ?? {},
      camposParaSugerir: iaFields.map((f) => ({ key: f.key, label: f.label, group: f.group })),
    };

    const userPrompt =
      "Gere sugestões para cada campo pedagógico abaixo. Para cada chave em camposParaSugerir, retorne um array " +
      "de objetos { id: string único, label: string, descricao?: string, fonte?: string }. " +
      "Exemplo: { \"objetivos_gerais\": [{ \"id\": \"obj1\", \"label\": \"...\", \"fonte\": \"BNCC\" }], ... }. " +
      "Retorne SOMENTE o JSON.\n\n" +
      JSON.stringify(payload);

    const response = await model.generateContent(userPrompt);

    const rawText = response.response.text();

    let parsed: Record<string, IaSugestao[]>;
    try {
      parsed = JSON.parse(rawText) as Record<string, IaSugestao[]>;
    } catch {
      const firstBrace = rawText.indexOf("{");
      const lastBrace = rawText.lastIndexOf("}");
      if (firstBrace === -1 || lastBrace === -1 || lastBrace <= firstBrace) {
        return NextResponse.json(
          { error: "Resposta inválida do modelo. Não foi possível extrair JSON." },
          { status: 502 },
        );
      }
      parsed = JSON.parse(rawText.slice(firstBrace, lastBrace + 1)) as Record<string, IaSugestao[]>;
    }

    return NextResponse.json({ sugestoes: parsed });
  } catch (error) {
    console.error("Erro na rota /api/gerar-plano:", error);
    return NextResponse.json({ error: "Falha ao gerar plano com IA." }, { status: 500 });
  }
}

