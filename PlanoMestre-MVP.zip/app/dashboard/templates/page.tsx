import Link from "next/link";
import { FileText } from "lucide-react";

import { requireCurrentUserProfile } from "../../../lib/auth/session";
import { getUserTemplateOptions } from "../../../lib/services/firestore/dashboard.server";
import { TemplatesUploader } from "../../../components/templates/templates-uploader";
import { TemplatesList } from "../../../components/templates/templates-list";

export const dynamic = "force-dynamic";

export default async function TemplatesPage() {
  const user = await requireCurrentUserProfile();
  const templates = await getUserTemplateOptions(user.uid);

  return (
    <div className="space-y-8">
      <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-500">
            Meus templates
          </p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
            Modelos oficiais da escola
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Centralize modelos anuais, semestrais ou quinzenais da sua escola para gerar planos consistentes.
          </p>
        </div>
        <Link
          href="/dashboard/gerar"
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
        >
          Abrir gerador de planos
        </Link>
      </header>

      {/* Linha 1: card de upload */}
      <section>
        <TemplatesUploader userId={user.uid} />
      </section>

      {/* Linha 2: lista de templates cadastrados */}
      <section className="rounded-3xl border border-slate-200 bg-white p-6">
        <div className="flex items-center justify-between gap-4">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <FileText className="h-4 w-4 text-slate-500" />
            Templates cadastrados
          </h2>
          {templates.length > 0 ? (
            <p className="text-xs text-slate-500">
              {templates.length} {templates.length === 1 ? "modelo disponível" : "modelos disponíveis"}
            </p>
          ) : null}
        </div>

        {templates.length === 0 ? (
          <p className="mt-4 text-sm text-slate-600">
            Nenhum template encontrado para <span className="font-medium">{user.nome || user.email}</span>.
            Adicione pelo menos um modelo para liberar completamente o fluxo de geração de planos.
          </p>
        ) : (
          <TemplatesList templates={templates} />
        )}
      </section>
    </div>
  );
}

