import Link from "next/link";
import { ArrowLeft, Clock, Download, FileText } from "lucide-react";

import { requireCurrentUserProfile } from "../../../lib/auth/session";
import { getUserPlanos } from "../../../lib/services/firestore/dashboard.server";

export const dynamic = "force-dynamic";

const statusLabels: Record<string, string> = {
  rascunho: "Rascunho",
  aguardando_geracao: "Aguardando geração",
  aguardando_aprovacao: "Aguardando aprovação",
  processando: "Processando",
  gerado: "Gerado",
  erro: "Erro",
};

function formatDate(value: string) {
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "medium" }).format(new Date(value));
}

export default async function HistoricoPage() {
  const user = await requireCurrentUserProfile();
  const planos = await getUserPlanos(user.uid);

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4">
        <Link
          href="/dashboard"
          className="inline-flex w-fit items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-slate-950"
        >
          <ArrowLeft className="h-4 w-4" />
          Voltar ao dashboard
        </Link>
        <div className="flex items-center gap-3">
          <div className="rounded-2xl bg-slate-100 p-3 text-slate-600">
            <Clock className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-950">Histórico de planos</h1>
            <p className="text-sm text-slate-600">Visualize e baixe os planos gerados.</p>
          </div>
        </div>
      </div>

      {planos.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center">
          <FileText className="mx-auto h-12 w-12 text-slate-400" />
          <h2 className="mt-4 text-lg font-semibold text-slate-950">Nenhum plano ainda</h2>
          <p className="mt-2 text-sm text-slate-600">
            Gere seu primeiro plano no assistente de geração.
          </p>
          <Link
            href="/dashboard/gerar"
            className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-800"
          >
            Gerar plano
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {planos.map((plano) => (
            <div
              key={plano.id}
              className="flex flex-col gap-4 rounded-3xl border border-slate-200 bg-white p-5 sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <p className="font-medium text-slate-950">Plano #{plano.id.slice(0, 8)}</p>
                <p className="mt-1 text-sm text-slate-600">
                  Template: {plano.template_id.slice(0, 8)}... · {formatDate(plano.data_geracao)}
                </p>
                <span
                  className={`mt-2 inline-block rounded-full px-3 py-1 text-xs font-medium ${
                    plano.status === "gerado"
                      ? "bg-emerald-100 text-emerald-800"
                      : plano.status === "erro"
                        ? "bg-rose-100 text-rose-800"
                        : "bg-slate-100 text-slate-700"
                  }`}
                >
                  {statusLabels[plano.status] ?? plano.status}
                </span>
              </div>
              <div className="flex gap-2">
                {(plano.status === "gerado" || plano.status === "aguardando_geracao") && Object.keys(plano.conteudo_gerado ?? {}).length > 0 && (
                  <a
                    href={`/api/planos/${plano.id}/download`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-950 hover:text-slate-950"
                  >
                    <Download className="h-4 w-4" />
                    Baixar PDF
                  </a>
                )}
                <Link
                  href={`/dashboard/gerar?plano=${plano.id}`}
                  className="inline-flex items-center gap-2 rounded-2xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-950 hover:text-slate-950"
                >
                  Ver detalhes
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
