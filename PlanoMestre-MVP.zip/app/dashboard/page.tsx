import Link from "next/link";
import { BookCopy, Clock3, FolderKanban, Rocket, Sparkles } from "lucide-react";

import { StatCard } from "../../components/dashboard/stat-card";
import { requireCurrentUserProfile } from "../../lib/auth/session";
import { getDashboardStats } from "../../lib/services/firestore/dashboard.server";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await requireCurrentUserProfile();
  const stats = await getDashboardStats(user);

  const cards = [
    {
      title: "Templates ativos",
      value: String(stats.totalTemplates),
      description: "Estruturas disponíveis para gerar planos com consistência documental.",
      icon: FolderKanban,
    },
    {
      title: "Planos gerados no mês",
      value: String(stats.planosGeradosMes),
      description: "Planos concluídos no ciclo atual e prontos para exportação PDF/DOCX.",
      icon: BookCopy,
    },
    {
      title: "Planos em fila",
      value: String(stats.planosPendentes),
      description: "Rascunhos ou execuções aguardando geração e revisão pedagógica.",
      icon: Clock3,
    },
    {
      title: "Tokens usados no mês",
      value: String(stats.tokensUsadosMes),
      description: `Consumo do plano ${stats.planoAtual} para operações com IA neste mês.`,
      icon: Sparkles,
    },
  ];

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto flex max-w-7xl flex-col gap-8 px-6 py-10">
        <section className="rounded-[2rem] bg-slate-950 px-8 py-10 text-white shadow-xl">
          <div className="flex flex-col gap-8 xl:flex-row xl:items-end xl:justify-between">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.24em] text-emerald-300">Dashboard</p>
              <h1 className="mt-3 text-4xl font-semibold tracking-tight">Visão geral do PlanoMestre</h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-300">
                Acompanhe capacidade operacional, volume de geração e o estado atual dos fluxos pedagógicos do usuário
                autenticado.
              </p>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
              <p className="text-sm text-slate-300">Usuário autenticado</p>
              <p className="mt-2 text-xl font-semibold">{user.nome || user.email}</p>
              <p className="mt-1 text-sm text-slate-300">{user.escola_padrao ?? "Escola padrão ainda não definida."}</p>
            </div>
          </div>
        </section>

        <section className="grid gap-5 xl:grid-cols-4">
          {cards.map((card) => (
            <StatCard
              key={card.title}
              title={card.title}
              value={card.value}
              description={card.description}
              icon={card.icon}
            />
          ))}
        </section>

        <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
          <article className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-sm">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Resumo operacional</p>
            <h2 className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">Ambiente preparado para geração</h2>
            <p className="mt-4 text-sm leading-7 text-slate-600">
              O painel já combina autenticação via cookie seguro do Firebase, leitura protegida em Server Components e
              visão consolidada dos dados do professor na coleção `users`.
            </p>

            <div className="mt-8 grid gap-4 md:grid-cols-2">
              <div className="rounded-3xl bg-slate-50 p-5">
                <p className="text-sm font-medium text-slate-500">Plano contratado</p>
                <p className="mt-2 text-xl font-semibold text-slate-950">{stats.planoAtual}</p>
              </div>
              <div className="rounded-3xl bg-slate-50 p-5">
                <p className="text-sm font-medium text-slate-500">Escola padrão</p>
                <p className="mt-2 text-xl font-semibold text-slate-950">
                  {user.escola_padrao ?? "Defina uma escola"}
                </p>
              </div>
            </div>
          </article>

          <aside className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-sm">
            <div className="flex items-center gap-3">
              <span className="rounded-2xl bg-emerald-50 p-3 text-emerald-600">
                <Rocket className="h-5 w-5" />
              </span>
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-slate-500">Próxima ação</p>
                <h2 className="text-2xl font-semibold tracking-tight text-slate-950">Gerar novo plano</h2>
              </div>
            </div>

            <p className="mt-4 text-sm leading-7 text-slate-600">
              Lance um novo wizard para consolidar template, dados da turma, referências BNCC/SAEB e aprovação humana.
            </p>

            <Link
              href="/dashboard/gerar"
              className="mt-6 inline-flex items-center justify-center rounded-2xl bg-slate-950 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Abrir gerador multi-step
            </Link>
          </aside>
        </section>
      </div>
    </main>
  );
}
