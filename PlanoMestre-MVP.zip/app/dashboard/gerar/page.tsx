import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import { PlanGenerationWizard } from "../../../components/planos/plan-generation-wizard";
import { requireCurrentUserProfile } from "../../../lib/auth/session";
import { getUserTemplateOptions } from "../../../lib/services/firestore/dashboard.server";

export const dynamic = "force-dynamic";

export default async function GerarPlanoPage() {
  const user = await requireCurrentUserProfile();
  const templates = await getUserTemplateOptions(user.uid);

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-6 py-10">
        <div className="flex flex-col gap-4">
          <Link
            href="/dashboard"
            className="inline-flex w-fit items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-slate-950"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar ao dashboard
          </Link>

          <div className="rounded-[2rem] border border-slate-200 bg-white px-8 py-8 shadow-sm">
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-emerald-600">Geração assistida</p>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">Fluxo multi-step de planos</h1>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-600">
              {user.nome || user.email}, revise todos os dados pedagógicos antes de aprovar o envio para o pipeline de IA.
              O wizard já prepara o documento com o template correto e marca o registro em `planos`.
            </p>
          </div>
        </div>

        {templates.length === 0 ? (
          <section className="rounded-[2rem] border border-dashed border-slate-300 bg-white p-10 text-center shadow-sm">
            <h2 className="text-2xl font-semibold tracking-tight text-slate-950">Nenhum template disponível</h2>
            <p className="mt-4 text-sm leading-7 text-slate-600">
              Cadastre ao menos um template na coleção `templates` para habilitar a geração orientada por IA.
            </p>
            <Link
              href="/dashboard"
              className="mt-6 inline-flex items-center justify-center rounded-2xl border border-slate-300 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-slate-950 hover:text-slate-950"
            >
              Voltar para a visão geral
            </Link>
          </section>
        ) : (
          <PlanGenerationWizard
            userId={user.uid}
            userName={user.nome || user.email}
            availableTemplates={templates}
          />
        )}
      </div>
    </main>
  );
}
