export type TemplateFieldKind =
  | "text"
  | "textarea"
  | "select"
  | "multiselect"
  | "number"
  | "date";

export type TemplateFieldRole = "manual" | "ia_sugerida";

export type TemplateFieldGroup =
  | "dados_turma"
  | "objetivos"
  | "competencias"
  | "habilidades"
  | "conteudos"
  | "avaliacao"
  | "outros";

export interface TemplateFieldSchema {
  key: string;
  label: string;
  type: TemplateFieldKind;
  required: boolean;
  role?: TemplateFieldRole;
  group?: TemplateFieldGroup;
  placeholder?: string;
  helperText?: string;
  options?: string[];
}

export interface UserProfile {
  uid: string;
  nome: string;
  email: string;
  escola_padrao: string | null;
  plano: string;
  tokens_usados_mes: number;
}

export interface TemplateRecord {
  id: string;
  user_id: string;
  nome: string;
  escola_nome?: string | null;
  tipo_plano?: string | null;
  schema_campos: TemplateFieldSchema[];
  data_criacao: string;
}

export interface CreateTemplateInput {
  user_id: string;
  nome: string;
  escola_nome?: string;
  tipo_plano?: string;
  schema_campos: TemplateFieldSchema[];
  data_criacao?: string;
}

export interface UpdateTemplateInput {
  nome?: string;
  schema_campos?: TemplateFieldSchema[];
}

export type PlanoStatus =
  | "rascunho"
  | "aguardando_geracao"
  | "aguardando_aprovacao"
  | "processando"
  | "gerado"
  | "erro";

export interface PlanoRecord {
  id: string;
  user_id: string;
  template_id: string;
  conteudo_gerado: Record<string, unknown>;
  data_geracao: string;
  status: PlanoStatus;
}

export interface CreatePlanoInput {
  user_id: string;
  template_id: string;
  conteudo_gerado: Record<string, unknown>;
  status: PlanoStatus;
  data_geracao?: string;
}

export interface UpdatePlanoInput {
  template_id?: string;
  conteudo_gerado?: Record<string, unknown>;
  status?: PlanoStatus;
}

export interface DashboardStats {
  totalTemplates: number;
  planosGeradosMes: number;
  planosPendentes: number;
  tokensUsadosMes: number;
  planoAtual: string;
}

export interface TemplateOption {
  id: string;
  nome: string;
  escolaNome?: string | null;
  tipoPlano?: string | null;
  campoCount: number;
  criadoEm: string;
  schema_campos?: TemplateFieldSchema[];
}

export interface IaSugestao {
  id: string;
  label: string;
  descricao?: string;
  fonte?: string;
}

export interface GerarPlanoWizardValues {
  templateId: string;
  nomeTurma: string;
  etapaEnsino: "Educação Infantil" | "Ensino Fundamental" | "Ensino Médio";
  anoSerie: string;
  componenteCurricular: string;
  quantidadeAulas: number;
  contextoTurma: string;
  objetivoGeral: string;
  habilidadesBncc: string;
  referenciaSaeb: string;
  observacoes: string;
  aprovacaoIA: boolean;
}
